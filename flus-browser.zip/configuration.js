export default {
    app_endpoint: 'https://app.flus.fr',
};
